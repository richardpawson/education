﻿namespace TechnicalServices
{
    public interface IRandomGenerator
    {
        int Next(int minValue, int maxValue);
    }
}
