﻿namespace PredatorPrey
{
    class Location
    {
        public Fox Fox;
        public Warren Warren;

        public Location()
        {
            Fox = null;
            Warren = null;
        }
    }
}
