﻿using Drawing.Model;

namespace Drawing.DataFixture
{
    public static class Examples
    {
        public static Shape[] Drawing1 =new Shape[] {
        new Circle(2,2, 3.5),
        new Circle(3,3, 7.81),
        new Rectangle(4,4, 12, 17),
        new Circle(5,5,8.889) };
    }
}
