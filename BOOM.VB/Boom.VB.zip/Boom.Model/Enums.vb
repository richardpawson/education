
Namespace Boom.Model
	Public Enum Orientations
		Horizontal
		Vertical
	End Enum

	Public Enum SquareValues
		Empty
		Miss
		Hit
	End Enum
End Namespace

'=======================================================
'Service provided by Telerik (www.telerik.com)
'Conversion powered by NRefactory.
'Twitter: @telerik
'Facebook: facebook.com/telerik
'=======================================================
