
Namespace Boom.Model
	Public Interface IWeapon
		Sub Fire(col As Integer, row As Integer, Board As GameBoard)
	End Interface
End Namespace

'=======================================================
'Service provided by Telerik (www.telerik.com)
'Conversion powered by NRefactory.
'Twitter: @telerik
'Facebook: facebook.com/telerik
'=======================================================
