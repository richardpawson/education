﻿namespace Boom.Model
{
    public enum Orientations
    {
        Horizontal, Vertical
    }

    public enum SquareValues
    {
        Empty, Miss, Hit
    }
}
